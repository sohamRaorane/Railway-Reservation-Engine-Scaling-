package com.soham.railway_reservation_engine.bookings.repository;


import com.soham.railway_reservation_engine.bookings.entity.Booking;


import org.springframework.data.jpa.repository.JpaRepository;


import java.util.Optional;


public interface BookingRepository extends JpaRepository<Booking, Long> {
    Optional<Booking> findByPnr(String pnr);
}
