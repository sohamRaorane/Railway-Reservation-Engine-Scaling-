package com.soham.railway_reservation_engine.quotaSeatAllocation.repository;

import com.soham.railway_reservation_engine.quota.entity.Quota;
import com.soham.railway_reservation_engine.quotaSeatAllocation.entity.QuotaSeatAllocation;
import com.soham.railway_reservation_engine.schedule.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface QuotaSeatAllocationRepository
        extends JpaRepository<QuotaSeatAllocation, Long> {

    Optional<QuotaSeatAllocation> findByScheduleAndQuota(
            Schedule schedule,
            Quota quota
    );
}