package com.soham.railway_reservation_engine.payment.repository;

import com.soham.railway_reservation_engine.bookings.entity.Booking;
import com.soham.railway_reservation_engine.payment.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;



import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByBooking(Booking booking);

    Optional<Payment> findByTransactionId(String transactionId);
}
