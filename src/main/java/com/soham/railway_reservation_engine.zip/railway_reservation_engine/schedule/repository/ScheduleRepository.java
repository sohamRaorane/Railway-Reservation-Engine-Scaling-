package com.soham.railway_reservation_engine.schedule.repository;

import com.soham.railway_reservation_engine.schedule.entity.Schedule;
import com.soham.railway_reservation_engine.train.entity.Train;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ScheduleRepository extends JpaRepository<Schedule, Long> {

    //this is for find the schedule for  a train X on journery date Y
    Optional<Schedule> findByTrainAndJourneyDate(Train train, LocalDate journeyDate);
    List<Schedule> findByTrain(Train train);

}