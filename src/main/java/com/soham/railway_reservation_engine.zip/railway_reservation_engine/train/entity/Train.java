package com.soham.railway_reservation_engine.train.entity;

import com.soham.railway_reservation_engine.common.enums.TrainType;
import jakarta.persistence.*;
import lombok.*;


@Entity
@Table(
        name = "trains"
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Train {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 10)
    private String number;

    @Column(nullable = false, length = 100)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private TrainType type;
}
