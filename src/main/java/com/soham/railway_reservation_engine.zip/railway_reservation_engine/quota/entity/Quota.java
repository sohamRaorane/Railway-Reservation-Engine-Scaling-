package com.soham.railway_reservation_engine.quota.entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "quotas")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Quota {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false,
            unique = true,
            length = 10)
    private String code;


    @Column(nullable = false,length = 100)
    private String name;
}
