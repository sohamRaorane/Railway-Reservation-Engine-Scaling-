-- =====================================================================
-- V20__fix_referential_integrity_and_missing_relationships.sql
--
-- Issues found comparing the live schema against the ER diagram:
--   1. RAC has no quota_id — inconsistent with WAITLIST, which is
--      correctly quota-scoped. Real IRCTC-style RAC is also per-quota
--      (GNRAC, LDRAC, etc.), and the diagram implies this scoping
--      that the table never actually had.
--   2. PAYMENT_HISTORY uses a polymorphic (reference_id + entry_type)
--      pointer with NO real foreign key — nothing stops reference_id
--      from pointing at a row that doesn't exist. This is the single
--      biggest consistency gap: the diagram draws paid_by/may_have
--      relationships that the actual columns can't enforce.
--   3. Several mandatory ("exactly one") relationships shown in the
--      ER diagram (the "||" side) are NOT backed by NOT NULL — e.g.
--      bookings.user_id, passengers.booking_id, seats.coach_id.
--      A nullable FK silently allows the "impossible" case the
--      diagram says can't happen.
--   4. No ON DELETE behavior was ever defined — every FK defaults to
--      NO ACTION, which is fine for "never delete this" parents
--      (users, schedules, quotas) but wrong for rows that make no
--      sense standalone (a route with no train, a seat with no coach).
--
-- NOTE: Default Postgres FK constraint names follow
-- <table>_<column>_fkey when declared inline in CREATE TABLE. Run
-- \d <table> in psql first to confirm — if you're on a version where
-- names differ, adjust the DROP CONSTRAINT lines accordingly before
-- running this.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. RAC: add quota scoping to match WAITLIST's design
-- ---------------------------------------------------------------------
ALTER TABLE rac ADD COLUMN quota_id BIGINT;

-- Backfill from the booking behind each RAC'd passenger
UPDATE rac r
SET quota_id = b.quota_id
FROM passengers p
         JOIN bookings b ON b.id = p.booking_id
WHERE r.passenger_id = p.id;

ALTER TABLE rac
    ALTER COLUMN quota_id SET NOT NULL,
    ADD CONSTRAINT rac_quota_id_fkey FOREIGN KEY (quota_id) REFERENCES quotas(id),
    ADD CONSTRAINT uq_rac_schedule_quota_number UNIQUE (schedule_id, quota_id, rac_number);

CREATE INDEX idx_rac_schedule_quota ON rac(schedule_id, quota_id, rac_number);

-- ---------------------------------------------------------------------
-- 2. PAYMENT_HISTORY: replace the unenforceable polymorphic pointer
--    with two explicit nullable FKs + a CHECK guaranteeing exactly one
-- ---------------------------------------------------------------------
ALTER TABLE payment_history
    ADD COLUMN payment_id BIGINT REFERENCES payments(id),
    ADD COLUMN refund_id BIGINT REFERENCES refunds(id);

UPDATE payment_history SET payment_id = reference_id WHERE entry_type = 'PAYMENT';
UPDATE payment_history SET refund_id  = reference_id WHERE entry_type = 'REFUND';

ALTER TABLE payment_history
    DROP COLUMN reference_id,
    ADD CONSTRAINT chk_payment_history_reference CHECK (
        (entry_type = 'PAYMENT' AND payment_id IS NOT NULL AND refund_id IS NULL)
            OR
        (entry_type = 'REFUND'  AND refund_id  IS NOT NULL AND payment_id IS NULL)
        );

CREATE INDEX idx_payment_history_payment ON payment_history(payment_id);
CREATE INDEX idx_payment_history_refund  ON payment_history(refund_id);

-- ---------------------------------------------------------------------
-- 3. Enforce NOT NULL on every mandatory ("exactly one") FK per the
--    ER diagram's cardinalities
-- ---------------------------------------------------------------------
ALTER TABLE refresh_tokens        ALTER COLUMN user_id      SET NOT NULL;

ALTER TABLE routes                ALTER COLUMN train_id     SET NOT NULL;
ALTER TABLE routes                ALTER COLUMN station_id   SET NOT NULL;

ALTER TABLE coaches               ALTER COLUMN train_id     SET NOT NULL;

ALTER TABLE seats                 ALTER COLUMN coach_id     SET NOT NULL;

ALTER TABLE schedules             ALTER COLUMN train_id     SET NOT NULL;

ALTER TABLE quota_seat_allocation ALTER COLUMN schedule_id  SET NOT NULL;
ALTER TABLE quota_seat_allocation ALTER COLUMN coach_id     SET NOT NULL;
ALTER TABLE quota_seat_allocation ALTER COLUMN quota_id     SET NOT NULL;

ALTER TABLE bookings              ALTER COLUMN user_id      SET NOT NULL;
ALTER TABLE bookings              ALTER COLUMN schedule_id  SET NOT NULL;
ALTER TABLE bookings              ALTER COLUMN quota_id     SET NOT NULL;

ALTER TABLE passengers            ALTER COLUMN booking_id   SET NOT NULL;
-- passengers.seat_id stays NULLABLE on purpose — WL/unconfirmed passengers have no seat yet

ALTER TABLE pnr_state_history     ALTER COLUMN booking_id   SET NOT NULL;

ALTER TABLE waitlist              ALTER COLUMN schedule_id  SET NOT NULL;
ALTER TABLE waitlist              ALTER COLUMN quota_id     SET NOT NULL;
ALTER TABLE waitlist              ALTER COLUMN passenger_id SET NOT NULL;

ALTER TABLE rac                   ALTER COLUMN schedule_id  SET NOT NULL;
ALTER TABLE rac                   ALTER COLUMN seat_id      SET NOT NULL;
ALTER TABLE rac                   ALTER COLUMN passenger_id SET NOT NULL;

ALTER TABLE payments              ALTER COLUMN booking_id   SET NOT NULL;

ALTER TABLE refunds               ALTER COLUMN booking_id   SET NOT NULL;

ALTER TABLE booking_history       ALTER COLUMN user_id      SET NOT NULL;
ALTER TABLE booking_history       ALTER COLUMN booking_id   SET NOT NULL;

ALTER TABLE payment_history       ALTER COLUMN user_id      SET NOT NULL;
ALTER TABLE payment_history       ALTER COLUMN booking_id   SET NOT NULL;

-- ---------------------------------------------------------------------
-- 4. Recreate FKs with explicit ON DELETE behavior.
--    CASCADE  -> child row is meaningless without its parent
--    RESTRICT -> audit/financial row — never silently lose it
--    (left as default NO ACTION where the parent, e.g. users/schedules/
--    quotas, should simply never be deletable while children exist)
-- ---------------------------------------------------------------------
ALTER TABLE routes DROP CONSTRAINT routes_train_id_fkey;
ALTER TABLE routes ADD CONSTRAINT routes_train_id_fkey
    FOREIGN KEY (train_id) REFERENCES trains(id) ON DELETE CASCADE;

ALTER TABLE coaches DROP CONSTRAINT coaches_train_id_fkey;
ALTER TABLE coaches ADD CONSTRAINT coaches_train_id_fkey
    FOREIGN KEY (train_id) REFERENCES trains(id) ON DELETE CASCADE;

ALTER TABLE seats DROP CONSTRAINT seats_coach_id_fkey;
ALTER TABLE seats ADD CONSTRAINT seats_coach_id_fkey
    FOREIGN KEY (coach_id) REFERENCES coaches(id) ON DELETE CASCADE;

ALTER TABLE quota_seat_allocation DROP CONSTRAINT quota_seat_allocation_schedule_id_fkey;
ALTER TABLE quota_seat_allocation ADD CONSTRAINT quota_seat_allocation_schedule_id_fkey
    FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE;

ALTER TABLE passengers DROP CONSTRAINT passengers_booking_id_fkey;
ALTER TABLE passengers ADD CONSTRAINT passengers_booking_id_fkey
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE;

ALTER TABLE payments DROP CONSTRAINT payments_booking_id_fkey;
ALTER TABLE payments ADD CONSTRAINT payments_booking_id_fkey
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE RESTRICT;

ALTER TABLE refunds DROP CONSTRAINT refunds_booking_id_fkey;
ALTER TABLE refunds ADD CONSTRAINT refunds_booking_id_fkey
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE RESTRICT;

ALTER TABLE pnr_state_history DROP CONSTRAINT pnr_state_history_booking_id_fkey;
ALTER TABLE pnr_state_history ADD CONSTRAINT pnr_state_history_booking_id_fkey
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE RESTRICT;

ALTER TABLE booking_history DROP CONSTRAINT booking_history_booking_id_fkey;
ALTER TABLE booking_history ADD CONSTRAINT booking_history_booking_id_fkey
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE RESTRICT;

ALTER TABLE payment_history DROP CONSTRAINT payment_history_booking_id_fkey;
ALTER TABLE payment_history ADD CONSTRAINT payment_history_booking_id_fkey
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE RESTRICT;

-- =====================================================================
-- End V20
-- =====================================================================